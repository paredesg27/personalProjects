package com.example.andriodapptest

data class Character(
    val name: String,
    val age: Int,
    val image: String,
    val job: String,
    val id: Int,
    val companies: List<String>
)
